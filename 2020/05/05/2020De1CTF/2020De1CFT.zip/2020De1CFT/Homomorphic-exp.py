from pwn import *
#context.log_level = 'debug'

import hashlib
sh = remote("106.52.135.150","8848")
sh.recvuntil("sha256(XXXX+")
pa = sh.recv(len('SLhlaef5L6nM6pYx'))
sh.recvuntil("== ")
me = sh.recv(len('3ade7863765f07a3fbb9d853a00ffbe0485c30eb607105196b0d1854718a7b6c'))
sh.recvuntil("XXXX:")

table = '0123456789zxcvbnmasdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP'

def getpwd(password,mess):
    Password = password
    for i in table:
        for j in table:
            for k in table:
                for l in table:
                    password=i+j+k+l+Password
                    if hashlib.sha256(password.encode()).hexdigest() == mess:
                        return i+j+k+l
sh.sendline(getpwd(pa,me))


sh.recvuntil("The enc flag is: \n")
FLAG = []
for _ in range(44):
    a = sh.recvline().replace("]","").replace("[","").split(",")
    a = [ (int(_)-1) for _ in a]
    b = sh.recvline().replace("]","").replace("[","").split(",")
    b = [ (int(_)-1) for _ in b]
    FLAG.append([a,b])

flag = ''

def dec(s):
    sh.recvuntil("(Separated by commas):\n")
    sh.sendline((str(s).replace("]","").replace("[","")))
    
for i in range(44):
    ans = 0
    sh.recvuntil("choice:\n")
    sh.sendline("Decrypt")
    b = FLAG[i][1]
    a = FLAG[i][0]
    dec(a)
    dec(b)
    sh.recvuntil("The index:\n")
    sh.sendline("0")
    sh.recvuntil("The result is: \n")
    ans += int(sh.recvuntil("\n")[:-1])
    flag += chr(ans % 128)
    print(flag)
