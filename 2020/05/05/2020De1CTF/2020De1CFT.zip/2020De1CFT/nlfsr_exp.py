#https://wiki.x10sec.org/crypto/streamcipher/fsr/nfsr/
for a in range(2):
    for b in range(2):
        for e in range(2):
            print a,b,e,(a*b)^(b*e)^e
n = [6,13,19,19]

cycle = 1
for i in n:
    cycle = cycle*(pow(2,i)-1)
print cycle


def lfsr(R, mask):
    output = (R << 1) & 0xffffff
    i = (R & mask) & 0xffffff
    lastbit = 0
    while i != 0:
        lastbit ^= (i & 1)
        i = i >> 1
    output ^= lastbit
    return (output, lastbit)


def single_round(R1, R1_mask, R2, R2_mask, R3, R3_mask,R4,R4_mask):
    (R1_NEW, x1) = lfsr(R1, R1_mask)
    (R2_NEW, x2) = lfsr(R2, R2_mask)
    (R3_NEW, x3) = lfsr(R3, R3_mask)
    (R4_NEW, x4) = lfsr(R4, R4_mask)
    x5 = x3^x4
    return (R1_NEW, R2_NEW, R3_NEW,R4_NEW, (x1 * x2) ^ ((x2 ^ x5) * x5))


R1_mask = 0x505a1
R2_mask = 0x40f3f
R3_mask = 0x1f02
R4_mask = 0x31
n4 = 6
n3 = 13
n2 = 19
n1 = 19

def guess1(beg, end, num, mask):
    ansn = range(beg, end)
    data = open('data').read(num)
    #print(data)
    now = 0
    res = 0
    for i in ansn:
        r = i
        cnt = 0
        for j in range(num):
            r, lastbit = lfsr(r, mask)
            lastbit = str(lastbit)
            cnt += (lastbit == data[j])
        if 0.7 <= cnt/num <= 0.8:
            print('yes!:', cnt/num, i)
        #print(cnt/num,i)
        if i%10000 == 0:
            print(i)
            return(i)
    print('ok')

def guess34(beg1, end1, beg2, end2, num, mask1, mask2):
    ansn1 = range(beg1, end1)
    ansn2 = range(beg2, end2)
    data = open('./data').read(num)
    now = 0
    for i1 in ansn1:
        for i2 in ansn2:
            
            r1 = i1
            r2 = i2
            cnt = 0
            for j in range(num):
                r1, lastbit1 = lfsr(r1, mask1)
                r2, lastbit2 = lfsr(r2, mask2)
                cnt += (str(lastbit1 ^ lastbit2) == data[j])
            if 0.7 <= cnt/num <= 0.8:
                print('yes!:', cnt/num, i1, i2)
                return (i1,i2)
    print('ok')
    
    
def bruteforce2(x, z, r):
    data = open('./data').read(50)
    for y in range(pow(2, n2 - 1), pow(2, n2)):
        R1, R2, R3, R4 = x, y, z, r
        if y % 10000 == 0:
            print(y)
        flag = True
        for i in range(len(data)):
            (R1, R2, R3, R4, out) = single_round(R1, R1_mask, R2, R2_mask, R3, R3_mask, R4, R4_mask)
            if str(out) != data[i]:
                flag = False
                break
        if flag:
            print(y)
            return y
    print('fail')

#R1 = guess1(pow(2, n1 - 1), pow(2, n1), 1000, R1_mask)
#yes!: 0.728 363445
#print (R1)
#R3,R4 = guess34(pow(2, n3 - 1), pow(2, n3), pow(2, n4 - 1), pow(2, n4), 1000, R3_mask, R4_mask)
#yes!: 0.758 4406 63

R1 = 363445
R3 = 4406
R4 = 63
R2 = bruteforce2(R1, R3, R4)

print("De1CTF{"+hex(R1)[2:]+hex(R2)[2:]+hex(R3)[2:]+hex(R4)[2:]+"}")
