import string 
from Crypto.Util.number import getPrime as getprime ,long_to_bytes,bytes_to_long,inverse
from pwn import *
#context.log_level = "debug"
table='0123456789zxcvbnmasdfghjklqwertyuiopZXCVBNMASDFGHJKLQWERTYUIOP'
def sha256(content):
    return hashlib.sha256(content).hexdigest()
def add(p1,p2):
	if p1 == zero:
		return p2
	if p2 == zero:
		return p1
	(p1x,p1y),(p2x,p2y) = p1,p2
	if p1x == p2x and (p1y != p2y or p1y == 0):
	    return zero
	if p1x == p2x:
	    tmp = (3 * p1x * p1x + a) * inverse(2 * p1y , q) % q
	else:
	    tmp = (p2y - p1y) * inverse(p2x - p1x , q) % q
	x = (tmp * tmp - p1x - p2x) % q
	y = (tmp * (p1x - x) - p1y) % q
	return (int(x),int(y))


def mul(n,p):
	r = zero
	tmp = p
	while 0 < n:
	    if n & 1 == 1:
	        r = add(r,tmp)
	    n, tmp = n >> 1, add(tmp,tmp)
	return r

sh=remote("134.175.225.42","8848")
#sh=remote("0.0.0.0","8848")
sh.recvuntil("sha256(XXXX+")
pa=sh.recv(len('SLhlaef5L6nM6pYx'))
sh.recvuntil("== ")
m=sh.recv(len('3ade7863765f07a3fbb9d853a00ffbe0485c30eb607105196b0d1854718a7b6c'))
sh.recvuntil("XXXX:")
def getpwd(password,mess):
    #table = string.printable
    Password = password
    for i in table:
        for j in table:
            for k in table:
                for l in table:
                    password=i+j+k+l+Password
                    if sha256(password) == mess:
                        return i+j+k+l
def gcd(a, b):
    while b:
        a, b = b, a%b
    return a
    
def CRT(mi, ai):
    M = reduce(lambda x, y: x * y, mi)
    ai_ti_Mi = [a * (M / m) * inverse(M / m, m) for (m, a) in zip(mi, ai)]
    return reduce(lambda x, y: x + y, ai_ti_Mi) % M



q = 0xdd7860f2c4afe6d96059766ddd2b52f7bb1ab0fce779a36f723d50339ab25bbd
a = 0x4cee8d95bb3f64db7d53b078ba3a904557425e2a6d91c5dfbf4c564a3f3619fa
b = 0x56cbc73d8d2ad00e22f12b930d1d685136357d692fa705dae25c66bee23157b8
zero = (0,0)
import re
with open("data1.txt")as f:
    data = f.read()
ans = re.findall("\((.*?):(.*?):(.*?)\)",data)


#(getpwd(pa,m))
#sh.interactive()
sh.sendline(getpwd(pa,m))
print sh.recvuntil("X:\n")

sh.sendline(str(int(ans[0][0])).strip("L"))
sh.recvuntil("Y:\n")
sh.sendline(str(int(ans[0][1])).strip("L"))
Q = (int(ans[0][0]),int(ans[0][1]))
N=[]
N.append(int(ans[0][2]))
sh.recvuntil("choice:\n")
sh.sendline("Encrypt")
sh.recvuntil("hex):\n")
mess = "8"+"0"*(q.bit_length()//2 -1)
sh.sendline(mess)
sh.recvuntil("The result is:\n")
res = sh.recvuntil("\n")[:-1]
key = int(mess,16)^int(res,16)
x , y = key >> q.bit_length() , key & ((1 << q.bit_length()) - 1)
G = (x,y)
reslist=[]

for i in range(1,int(ans[0][2])):
    if mul(i,Q) == G:
        reslist.append(i)
        break

for each in ans[1:]:
    sh.recvuntil("Tell me your choice:\n")
    sh.sendline("Exchange")
    sh.recvuntil("X:\n")
    sh.sendline(str(int(each[0])).strip("L"))
    sh.recvuntil("Y:\n")
    sh.sendline(str(int(each[1])).strip("L"))
    sh.recvuntil("choice:\n")
    sh.sendline("Encrypt")
    sh.recvuntil("hex):\n")
    mess = "8"+"0"*(q.bit_length()//2 -1)
    sh.sendline(mess)
    sh.recvuntil("The result is:\n")
    res = sh.recvuntil("\n")[:-1]
    key = int(mess,16)^int(res,16)

    x , y = key >> q.bit_length() , key & ((1 << q.bit_length()) - 1)
    G = (x,y)   #key
    Q = (int(each[0]),int(each[1]))     #我们找到的低阶点Q
    for i in range(1,int(each[2])):
         if mul(i,Q) == G:
             reslist.append(i)      #secret的剩余
             N.append(int(each[2]));print (i,int(each[2]))      #secret的剩余对应的阶
             break

#print(N,reslist)
secret = CRT(N, reslist)
#print secret
#print(int(secret,16))
sh.recvuntil("Tell me your choice:\n")
sh.sendline("Backdoor")
sh.recvuntil("Give me the secret:\n")
sh.sendline(str(secret))
sh.interactive()
